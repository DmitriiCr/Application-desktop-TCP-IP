#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <stdbool.h>
#include <menu.h>
#include <sys/stat.h> // Library POUR LES S_IRUSR ETC ...
#include <fcntl.h> // Library pour creat 

#define MAX 10000

#define PORT 5554

void download(char* nomPhoto,int socket){
 	
	mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH; 	
 	int taille ; 
	FILE * inputFile;
	char test [] = "test2.png" ;
	creat(test,mode); 
	
	inputFile = fopen(test,"w" ) ; 				
									

	char *buffer = (char*) malloc(512*sizeof(char)) ; 
	int i=0;
	read(socket,&taille,sizeof(int));
	printf("notre fichier est de taille : %d\n",taille);
	
	
	while(taille>512){
		read(socket,&buffer,sizeof(char));						
	if(fputs(buffer,inputFile)==-1){
		printf("échec du fputs\n");
	} else {
		printf("réussite du fputs\n");
	}
	taille= taille-512;
	}
	fclose(inputFile);
}



void upload(char* nomPhoto){
	//ON OUVRE LE FICHIER NOM PHOTO en mode lecture
	//tant que buffers !=/0
	// je stock 512 octets dans le buffer 
	// que write dans le socket mis en argument
	//ON CLOSE ENSUITE LE FICHIER 
	
	char *buffer =(char*) malloc(512*sizeof(char)) ;
	char *buffer2 = (char*) malloc(512*sizeof(char)) ;
	int numread ;
	FILE * inputFile = fopen(nomPhoto,"rb" ) ;
	FILE * outFile = fopen("autre.png","w" ) ;
	fseek(inputFile,0,SEEK_END);
	int taille = ftell(inputFile) ;
	printf("notre fichier est de taille : %d\n",taille);
	fseek(inputFile,0,SEEK_SET);
	int tailleO = 512*sizeof(char);
	int res = -1;
	while (res != 0 /* feof( inputFile )  /*taille>0*/ ) { 
	  	res = fread(buffer,sizeof(char), tailleO,inputFile);
	  	//printf("test : %s\n",buffer);
	  	//printf("res = %d",res);
	  	
	  	fwrite(buffer, sizeof(char), res, outFile);
	  }
	  printf("fin upload\n");
	  fclose(inputFile);
}

int main(int argc, char *argv[]){

	char photo[]="amelie.png";
	//int socket = 5 ;
	//download(photo,socket);
	upload(photo);
	printf("bien vu\n");
	return 0;
}

