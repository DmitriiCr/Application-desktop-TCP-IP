#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <stdbool.h>
#include <menu.h>
#include <sys/stat.h> // Library POUR LES S_IRUSR ETC ...
#include <fcntl.h> // Library pour creat 

#define MAX 10000

#define PORT 5554
 /*	DOWNLOAD COTE CLIENT */
 
 /* 
 DIFFERENCE ENTRE DOWNLOAD CLIENT ET DOWNLOAD SERV ?
 
 ON OUVRE UN NOUVEAU FICHIER AVEC LE NOM ENTRÉE EN PARAMETRE
 SI CE FICHIER EXISTE DEJA ON LE CRÉE EN RAJOUTANT UN CHIFFRE A LA FIN => PERMET D'ITERER JUSQU'A AVOIR UN NOM DIFFÉRENT
 ON OUVRE ENSUITE CE FICHER GRACE A FOPEN 
 ON READ UN BUFFER CONTENANT UN CERTAIN NOMBRE D'OCTET DE LA PHOTO QUE L'ON CONCATENE DANS LE FICHIER FRAICHEMENT CRÉE
 JUSQU'A ARRIVÉ JUSQU'A AU CARACTERE DE FIN DE FICHER
 ON ENVOIE ENSUITE UN MESSAGE SI LE DOWNLOAD A ÉTÉ UNE RÉUSSITE OU NON*/
 
 /* DIFFERENCE POSSIBLE ENTRE DOWNLOAD CLIENT ET DOWNLOAD SERV 
 LA SOCKET D'ARRIVÉ ?
 LE NOMBRE D'OCTET RECU ?
 ...*/
 
 /* RETURN -1 SI IL Y'A UNE ERREUR OU VOID ?*/
 
 // int creat(char *nomfic, int perm); => CRÉE UN FICHIER 
 
 
void download(char* nomPhoto,int socket){
 	
	mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH; 	// on choisi les permissions a donner pour notre photo dl ici on a write read pour user et read pour les autres 
 	int reponse ;
	FILE * inputFile;
	//ON DOIT CREE LE IF NOMPHOTO ALREADY EXIST
	char test [] = "test2.png" ;
	creat(test,mode); //ON CREE LA NOUVELLE PHOTO RENVOIE -1 SI ERREUR
	
	inputFile = fopen(test,"wb" ) ; 				//ON OUVRE LE FICHIER EN MODE ECRITURE 
									//ON PEUT RECUPERER LA TAILLE DU SERVEUR POUR TOUT RECEVOIR D'UN COUP OU RECEVOIR PAQUET PAR PAQUET
									//ON PEUT RECUPERER LA TAILLE LA DIVISER PAR QUATRE? ET FAIRE UN BUFFER EQUIVALENT A 1/4 DE LA TAILLE POUR FAIRE 4 TELECHARGEMENTS DE TAILLE MOYENNE PLUTOT QUE UN GRAND  
	
									//read(socket,&taille,sizeof(int)); // ON RECUPERE LA TAILLE 
	char buffer[512] ; //(char*) malloc(512*sizeof(int)) ; // PARCE C'EST DES ENTIERS QUE L'ON RECOIS ? => SOLUTION ON LIS TANT QU'IL Y A UN PAQUET  A LIRE 54 PAR 54 
	/*if (taille%4 = 0){
		taille=taille/4 ;
	} else( */
	int i=0;
	while(i!=137){
		//read(socket,&reponse,sizeof(reponse));
		read(socket,&buffer,sizeof(buffer));
		
		printf("on read :%s",buffer);
	
	 							
	if(fputs(&buffer,inputFile)==-1){
		printf("échec du fputs\n");
	} else {
		printf("réussite du fputs\n");
	}
	i++;
	}
	fclose(inputFile);
}

//plus besoin de la taille ducoup ????

/* LA FONCTION UPLOAD DOIS DONC 
WRITE LA TAILLE 
WRITE LES OCTETS */


/* LA FONCTION UPLOAD :
LA FONCTION UPLOAD DOIS ENVOYER LA TAILLE DU FICHIER  plus besoin de la taille avec la solution réponse serveur 
PUIS ENVOYER LES
*/
void upload(char* nomPhoto,int socket){
	//ON OUVRE LE FICHIER NOM PHOTO en mode lecture
	//tant que buffers !=/0
	// je stock 512 octets dans le buffer 
	// que write dans le socket mis en argument
	//ON CLOSE ENSUITE LE FICHIER 
	int commande = 1 ;
	char* buffer[512] ;//=(char*) malloc(512*sizeof(int)) ;
	FILE * inputFile ;
	inputFile = fopen(nomPhoto,"rb" ) ; //ON OUVRE LE FICHIER EN MODE LECTURE
	int i = 0 ;
	while ( ! feof( inputFile ) ) { 
	  	//write(socket,&commande,sizeof(commande));
	  	fgets( &buffer, 512, inputFile );
	  	write(socket,&buffer,sizeof(buffer));
	  	//printf("on envoie :%s",buffer);
	  	i++;
	  	//printf("on fait %d envoie",i);
	  }
	  commande = 0 ; 
	  write(socket,&commande,sizeof(commande));
	  fclose(inputFile);
}




/*int main(int argc, char *argv[]){
	/*char *adresse = NULL;
	long *port = malloc(sizeof(long));
	if(argc != 3){
		if(argc==1){
			printf("Attention il manque l'adresse IP du serveur.\n Usage ./client SERV_IP_ADDRESS SERV_PORT. \n");
			exit(1);
		} else if(argc==2){
			printf("Attention il manque le numéro de port du serveur.\n Usage ./client SERV_IP_ADDRESS SERV_PORT. \n");
			exit(1);
		}
	} else {
		*port = strtol(argv[1],NULL,10);
		adresse = argv[2];
		if(*port<1 || *port>65535){
            printf("Attention votre numéro de port doit être compris entre 1 et 65535\n");
            printf("Usage ./client SERV_IP_ADDRESS SERV_PORT\n");
            exit(1);
        }
		client(adresse, *port);
	}
	char photo[]="test.png";
	int socket = 5 ;
	download(photo,socket);
	upload(photo,socket);
	printf("bien vu");
	return 0;
}*/
	
	
	
