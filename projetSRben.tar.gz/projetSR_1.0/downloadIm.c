#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <stdbool.h>
#include <menu.h>
#include <sys/stat.h> // Library POUR LES S_IRUSR ETC ...
#include <fcntl.h> // Library pour creat 

#define MAX 10000

#define PORT 5554
 /*	DOWNLOAD COTE CLIENT */
 
 /* 
 DIFFERENCE ENTRE DOWNLOAD CLIENT ET DOWNLOAD SERV ?
 
 ON OUVRE UN NOUVEAU FICHIER AVEC LE NOM ENTRÉE EN PARAMETRE
 SI CE FICHIER EXISTE DEJA ON LE CRÉE EN RAJOUTANT UN CHIFFRE A LA FIN => PERMET D'ITERER JUSQU'A AVOIR UN NOM DIFFÉRENT
 ON OUVRE ENSUITE CE FICHER GRACE A FOPEN 
 ON READ UN BUFFER CONTENANT UN CERTAIN NOMBRE D'OCTET DE LA PHOTO QUE L'ON CONCATENE DANS LE FICHIER FRAICHEMENT CRÉE
 JUSQU'A ARRIVÉ JUSQU'A AU CARACTERE DE FIN DE FICHER
 ON ENVOIE ENSUITE UN MESSAGE SI LE DOWNLOAD A ÉTÉ UNE RÉUSSITE OU NON*/
 
 /* DIFFERENCE POSSIBLE ENTRE DOWNLOAD CLIENT ET DOWNLOAD SERV 
 LA SOCKET D'ARRIVÉ ?
 LE NOMBRE D'OCTET RECU ?
 ...*/
 
 /* RETURN -1 SI IL Y'A UNE ERREUR OU VOID ?*/
 
 // int creat(char *nomfic, int perm); => CRÉE UN FICHIER 
 /*
 
 
 
 FONCTION TEST AVEC BUFFER = 1 CARACTERE FAIRE ATTENTION A LA TAILLE on modulo et on ajoute un octet On recupere la taille  FREAD PLUS SIMPLE !  ET FWRITE ZEBI
 
 
 
 */
 
 
 
 
void download(char* nomPhoto,int socket){
 	
	mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH; 	// on choisi les permissions a donner pour notre photo dl ici on a write read pour user et read pour les autres 
 	int taille ; 
	FILE * inputFile;
	//ON DOIT CREE LE IF NOMPHOTO ALREADY EXIST
	char test [] = "photo/test2.png" ;
	creat(test,mode); //ON CREE LA NOUVELLE PHOTO RENVOIE -1 SI ERREUR
	
	inputFile = fopen(test,"w" ) ; 				//ON OUVRE LE FICHIER EN MODE ECRITURE 
									
									
	

	char *buffer = (char*) malloc(512*sizeof(char)) ; 
	read(socket,&taille,sizeof(int));
	printf("notre fichier est de taille : %d",taille);
	int res=-1 ;
	int paquet = 0 ;
	int tailleact=0;
	int pourcentage=0;
	int pourcentagetest=0;
	printf("DEBUT DU TELECHARGEMENT\n");
	printf("TELECHARGEMENT :[");
	while(res!=0){
		read(socket,&res,sizeof(int)); //on envoie res 
		//read(socket,&reponse,sizeof(reponse));
		read(socket,buffer,res);
		//printf("test1");
		//printf("on read :%c",buffer);
		//printf("res est egal a : %d\n",res);
		//printf("buffer : %s\n",buffer);
		fwrite(buffer, sizeof(char), res, inputFile);
		paquet++;
		tailleact=paquet*512;
		
			// ESSAIE DE BARRE DE TÉLÉCHARGEMENT
		pourcentage=(tailleact/taille)*100;
		if(pourcentage>pourcentagetest){
			printf("pourcentage : %d\n",pourcentage);
		}
		/*while(((tailleact/taille)*100)<100){
			printf("#");
		}*/
	pourcentagetest=(tailleact-1/taille)*100;
	}
	printf("]\n");
	printf("FIN DU TÉLÉCHARGEMENT\n");
	printf("on a recu : %d pour un fichier de taille : %d\n",paquet,taille);
	fclose(inputFile);
}

//plus besoin de la taille ducoup ????

/* LA FONCTION UPLOAD DOIS DONC 
WRITE LA TAILLE 
WRITE LES OCTETS */


/* LA FONCTION UPLOAD :
LA FONCTION UPLOAD DOIS ENVOYER LA TAILLE DU FICHIER  plus besoin de la taille avec la solution réponse serveur 
PUIS ENVOYER LES
*/
void upload(char* nomPhoto,int socket){
	//ON OUVRE LE FICHIER NOM PHOTO en mode lecture
	//tant que buffers !=/0
	// je stock 512 octets dans le buffer 
	// que write dans le socket mis en argument
	//ON CLOSE ENSUITE LE FICHIER 
	int paquet = 0;
	char *buffer =(char*) malloc(512*sizeof(char)) ;
	FILE * inputFile = fopen(nomPhoto,"rb" ) ;
	FILE * outFile = fopen("photo/test4.png","w" ) ;
	fseek(inputFile,0,SEEK_END); // DONNE LA TAILLE DU FICHIER
	int taille = ftell(inputFile) ;
	printf("notre fichier est de taille : %d\n",taille);
	write(socket,&taille,sizeof(int));
	fseek(inputFile,0,SEEK_SET);
	int res = -1 ;
	int tailleO = 512*sizeof(char);
	while ( res != 0 ) { 
	  	res = fread(buffer,sizeof(char), tailleO,inputFile);
	  	//printf("test : %s\n",buffer);
	  	//printf("res = %d\n",res);
	  	fwrite(buffer, sizeof(char), res, outFile);
	  	write(socket,&res,sizeof(int));
	  	write(socket,buffer,res);
	  	paquet++ ;
	  	
	  }
	  printf("on a recu %d pour un fichier de taille : %d\n",paquet,taille);
	  printf("fin upload\n");
	  fclose(inputFile);
}

	
	
	
	
	
 
 
 
 
 
 
