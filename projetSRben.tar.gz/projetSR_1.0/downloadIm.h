#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <stdbool.h>
#include <menu.h>
#include <sys/stat.h> // Library POUR LES S_IRUSR ETC ...
#include <fcntl.h> // Library pour creat 

#define MAX 10000

#define PORT 5554

void download(char* nomPhoto,int socket);

void upload(char* nomPhoto,int socket);
